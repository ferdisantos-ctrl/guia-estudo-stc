GUIA DE ESTUDO STC — PWA INSTALLABLE PACKAGE

Contents:
- index.html: app
- manifest.webmanifest: install metadata
- sw.js: offline cache service worker
- icons/: app icons

Deployment (GitHub Pages):
1. Create a GitHub account if needed and sign in.
2. Create a new public repository named guia-estudo-stc.
3. Upload all files and folders from this package to the repository root.
4. Open repository Settings > Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish; the site URL will be shown on the Pages screen.
8. Open that HTTPS URL on Android Chrome. Menu > Install app (or Add to Home screen) > Install.

IMPORTANT: PWA installation and service-worker offline support require HTTPS hosting. For a first installation, open the hosted URL online.
